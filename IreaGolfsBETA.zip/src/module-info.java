module IreaGolfsBETA {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;  // 이 줄을 추가하여 javafx.web 모듈을 포함시킵니다.
    requires java.sql;
	requires jdk.jsobject;    // SQLite를 사용 중인 경우 필요합니다.

    opens com.irea.application to javafx.fxml;
    exports com.irea.application;
}
