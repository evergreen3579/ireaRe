package com.irea.database.user;

import com.irea.database.connect.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class userDAO {

    // USER 추가 메서드
    public void addUser(userVO user) {
        String sql = "INSERT INTO USER (irea_id, irea_pw, name, role) VALUES (?, ?, ?, ?)";

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getIreaId());
            pstmt.setString(2, user.getIreaPw());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getRole());  // userVO에서 제공된 role 값 사용

            pstmt.executeUpdate();
            System.out.println("새 사용자 정보가 추가되었습니다.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 전체 사용자 정보 조회
    public List<userVO> getAllUsers() {
        String sql = "SELECT * FROM USER";
        List<userVO> userList = new ArrayList<>();

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                userVO user = new userVO();
                user.setUserId(rs.getInt("user_id"));
                user.setIreaId(rs.getString("irea_id"));
                user.setIreaPw(rs.getString("irea_pw"));
                user.setName(rs.getString("name"));
                user.setRole(rs.getString("role"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userList;
    }

    // 특정 사용자 정보 조회
    public userVO getUserById(int userId) {
        String sql = "SELECT * FROM USER WHERE user_id = ?";
        userVO user = null;

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    user = new userVO();
                    user.setUserId(rs.getInt("user_id"));
                    user.setIreaId(rs.getString("irea_id"));
                    user.setIreaPw(rs.getString("irea_pw"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    // 사용자 정보 수정 메서드
    public void updateUser(userVO user) {
        String sql = "UPDATE USER SET irea_id = ?, irea_pw = ?, name = ?, role = ? WHERE user_id = ?";

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getIreaId());
            pstmt.setString(2, user.getIreaPw());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getRole());
            pstmt.setInt(5, user.getUserId());

            pstmt.executeUpdate();
            System.out.println("사용자 정보가 업데이트되었습니다.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 사용자 정보 삭제 메서드
    public void deleteUser(int userId) {
        String sql = "DELETE FROM USER WHERE user_id = ?";

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
            System.out.println("사용자 정보가 삭제되었습니다.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // 특정 사용자 조회 (아이디로)
    public userVO getUserByIreaId(String ireaId) {
        String sql = "SELECT * FROM USER WHERE irea_id = ?";
        userVO user = null;

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ireaId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    user = new userVO();
                    user.setUserId(rs.getInt("user_id"));
                    user.setIreaId(rs.getString("irea_id"));
                    user.setIreaPw(rs.getString("irea_pw"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

}
