package com.irea.database.user;

public class userVO {
    private int userId;
    private String ireaId;
    private String ireaPw;
    private String name;
    private String role = "USER"; // 기본값 "USER"

    // 기본 생성자
    public userVO() {}

    // 매개변수 생성자
    public userVO(int userId, String ireaId, String ireaPw, String name, String role) {
        this.userId = userId;
        this.ireaId = ireaId;
        this.ireaPw = ireaPw;
        this.name = name;
        this.role = role;
    }

    // Getters and Setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getIreaId() {
        return ireaId;
    }

    public void setIreaId(String ireaId) {
        this.ireaId = ireaId;
    }

    public String getIreaPw() {
        return ireaPw;
    }

    public void setIreaPw(String ireaPw) {
        this.ireaPw = ireaPw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "userVO{" +
                "userId=" + userId +
                ", ireaId='" + ireaId + '\'' +
                ", ireaPw='" + ireaPw + '\'' +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
