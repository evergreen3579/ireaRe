package com.irea.application;

import com.irea.database.user.userDAO;
import com.irea.database.user.userVO;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // WebView 생성
        WebView webView = new WebView();
        WebEngine webEngine = webView.getEngine();

        // HTML 파일 로드
        webEngine.load(getClass().getResource("/login.html").toExternalForm());

        // 로그인 버튼을 눌렀을 때의 동작
        webEngine.setOnAlert(event -> {
            // HTML의 입력 필드에서 사용자 ID와 비밀번호 가져오기
            String username = (String) webEngine.executeScript("document.querySelector('input[type=\"text\"]').value");
            String password = (String) webEngine.executeScript("document.querySelector('input[type=\"password\"]').value");

            // 데이터베이스에서 사용자 정보 조회
            userDAO dao = new userDAO();
            userVO user = dao.getUserByIreaId(username);

            if (user != null && user.getIreaPw().equals(password)) {
                System.out.println("로그인 성공");
                if (user.getRole().equals("ADMIN")) {
                    // 관리자 화면으로 이동
                    webEngine.load(getClass().getResource("/adminHome.html").toExternalForm());
                } else {
                    // 일반 사용자 화면으로 이동
                    webEngine.load(getClass().getResource("/member_golf.html").toExternalForm());
                }
            } else {
                System.out.println("로그인 실패: 아이디 또는 비밀번호가 틀립니다.");
                webEngine.executeScript("document.querySelector('.login-window h1').innerHTML = '로그인 실패'");
            }
        });

        // Stage 설정
        Scene scene = new Scene(webView, 1000, 800);
        primaryStage.setTitle("로그인 페이지");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
