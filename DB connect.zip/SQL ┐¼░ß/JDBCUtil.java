package com.ire.database.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtil {
    
    // 데이터베이스 파일 경로 (상대 경로로 지정)
    private static final String URL = "jdbc:sqlite:./data/IREA.db";

    // 데이터베이스 연결을 반환하는 메서드
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // SQLite 데이터베이스 연결
            conn = DriverManager.getConnection(URL);
        } catch (SQLException e) {
            System.out.println("데이터베이스 연결 오류: " + e.getMessage());
        }
        return conn;
    }

    // 데이터베이스 연결 해제 메서드
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("데이터베이스 연결 해제 오류: " + e.getMessage());
            }
        }
    }
}
